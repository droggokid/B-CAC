
#include "project.h"
void offset_Zerodrift_calibrate(uint8_t, float, float,uint8_t);
void wait_for_weight( float, float,uint8_t);
float readWeight(uint8_t, float, float,uint8_t);
void initLoadcell(void);
