#include "project.h"
#include <stdio.h>
#include <inttypes.h>
#include "cy_syslib.h"  // Tilføj denne linje for at inkludere Cy_SysLib funktioner

#define MS_TO_TICKS(ms) ((ms) * 1000)  // Antallet af ticks i en millisekund

volatile uint32_t startTick = 0;
volatile uint32_t stopTick = 0;
static char outputBuffer[256];

void startTidsTagning()
{
    UART_1_PutString("tids tagning startet");
    startTick = Cy_SysLib_GetTick();  // Gem den aktuelle tick-værdi
}

void stopTidsTagning()
{
    stopTick = Cy_SysLib_GetTick();
    uint32_t elapsed = stopTick - startTick;
    snprintf(outputBuffer, sizeof(outputBuffer), "tiden er %" PRIu32 " ms\r\n", elapsed);
    UART_1_PutString(outputBuffer);
    // Udskriv 'elapsed' her for at se, hvor meget tid der er gået
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    UART_1_Start();
    Cy_SysLib_Init();  // Initialiser systembiblioteket for at bruge Cy_SysLib_GetTick

    UART_1_PutString("DC-Motor-PWM application started\r\n");
    UART_1_PutString("0: Stop\r\n");
    UART_1_PutString("1: Drive forwards\r\n");
    UART_1_PutString("2: Drive backwards\r\n");
    UART_1_PutString("q: Decrease speed\r\n");
    UART_1_PutString("w: Increase speed\r\n");

    for(;;)
    {
        startTidsTagning();
        CyDelay(2000);
        stopTidsTagning();
        startTidsTagning();
        CyDelay(1000);
        stopTidsTagning();
        
        /* Place your application code here. */
    }
}
