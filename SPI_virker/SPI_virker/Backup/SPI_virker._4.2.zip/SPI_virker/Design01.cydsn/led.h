/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

void initLed(void);
void startLedGreen(int8_t);
void stopLedGreen(void);
void startLedRed(int8_t);
void stopLedRed(void);
/* [] END OF FILE */
