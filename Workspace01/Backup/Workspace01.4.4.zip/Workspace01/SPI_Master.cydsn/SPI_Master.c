/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "SPI_Master.h"


void requestStatus(){
    SPIM_1_WriteTxData(0);
    
}

void spiSetup(){
    SPIM_1_EnableRxInt();
    SPIM_1_SetRxInterruptMode(SPIM_1_INT_ON_RX_NOT_EMPTY);
}

/* [] END OF FILE */
